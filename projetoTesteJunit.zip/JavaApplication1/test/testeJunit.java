/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import cadastro.Cadastro;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 254819
 */
public class testeJunit {

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() 
    
    @Test
    public void teste(){
    Cadastro cad = new Cadastro();
    if(cad.testarCampos("123456897")==false){
        System.out.print("Error");
    }else
        System.out.print("Teste ok");  
    }
        
    @Test
    public void testeNome(){
    Cadastro cad = new Cadastro();    
    if(cad.testarNome("1234560259")==false){
      System.out.print("Error");
    }else
        System.out.print("Teste ok");
    }
    
    @Test
    public void testeCPF(){
    Cadastro cad = new Cadastro();
    if(cad.testarCPF("12345689712")!=false){
        System.out.print("Error");
    }else
        System.out.print("Teste ok");  
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastro;



/**
 *
 * @author Caio
 */
public class Cadastro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        


}
    
         public void verificar(){
             CadastroCliente Cad = new CadastroCliente();
        Cad.verificaCamposObrigatorios();       
        
    }
         
         public boolean testarCampos(String rg){
             String testeRG = "123456789";
            return rg.length()==testeRG.length();
         }
         
         public boolean testarNome(String nome){
            String nomeTeste="1234567890";
            return nome.length()==nomeTeste.length();
         }
         public boolean testarCPF(String cpf){
             String testeCPF = "12345678912";
            return cpf.length()==testeCPF.length();
         }
    
}
